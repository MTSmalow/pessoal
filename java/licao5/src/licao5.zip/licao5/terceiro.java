package licao5;
import java.util.Random;
import java.util.Scanner;
public class terceiro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
